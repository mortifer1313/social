import AsciiHeader from '../AsciiHeader';

export default function AsciiHeaderExample() {
  return <AsciiHeader />;
}
